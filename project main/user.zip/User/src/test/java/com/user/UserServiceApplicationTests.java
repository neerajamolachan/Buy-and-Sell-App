package com.user;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.user.entity.User;
import com.user.service.UserService;

@SpringBootTest
class UserServiceApplicationTests {

	@Test
	void contextLoads() {
	}
	

    @Autowired
    private UserService userService;
    private User user;

    @BeforeEach
    public void setUp() {
    	user = new User();
        user.setUserId(1L);
        user.setEmail("Arya@gmail.com");
        user.setPhone("96555666555");
        user.setName("Arya");
        user.setPassword("Arya3343#");
       
    }
    @AfterEach
    public void tearDown() {
    	userService.deleteAll();
        user = null;
    }

    @Test
    public void givenGetAllUserThenShouldReturnListOfAllUsers() {
        User user = new User(2L, "Demo2", "Imneet", "Sample2","sample3");
       User user1 = new User(3L, "Demo3", "Imneet", "Sample3","sample4");
       userService.save(user);
       userService.save(user1);

        List<User> userList = (List<User>) userService.findAll();
        assertEquals("Demo3", userList.get(1).getName());
    }

    private void assertEquals(String string, String name) {
		// TODO Auto-generated method stub
		
	}
	@Test
    public void givenUserIdThenShouldReturnRespectiveUser() {
        User user = new User(9l, "Demo9", "Imneet", "SampleUser","sample");
        User user1 = userService.save(user);
        Optional<User> optional = userService.findById(user1.getUserId());
        assertEquals(user1.getUserId(), optional.get().getUserId());
        assertEquals(user1.getEmail(), optional.get().getEmail());
        assertEquals(user1.getPhone(), optional.get().getPhone());
        assertEquals(user1.getName(), optional.get().getName());
        assertEquals(user1.getPassword(), optional.get().getPassword());
    }
	private void assertEquals(Long userId, Long userId2) {
		// TODO Auto-generated method stub
		
	}



}
