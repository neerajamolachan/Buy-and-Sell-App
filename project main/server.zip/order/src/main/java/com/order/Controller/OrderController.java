package com.order.Controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.order.Entity.Order;
import com.order.exeception.CRUDControllerException;

import com.order.server.OrderService;


@RequestMapping("order")
@RestController
public class OrderController {
	
	private OrderService orderService;
	@Autowired
	public void setOrderService(OrderService orderService) {
		this.orderService = orderService;
	}
	
//	
	
	//All Orders
	@GetMapping("{username}/all")
	public ResponseEntity<List<Order>> getAll() {
		return ResponseEntity.ok(orderService.findAll());
	}
	
	//Purchase Product with Cart
	@PutMapping("/{username}/{Name}")
	public ResponseEntity<?> CreateNew1(@PathVariable String username,@PathVariable String Name) {
		
			try {	
					Order order=new Order();
					Class.forName("com.mysql.jdbc.Driver");
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/olx?autoReconnect=true&useSSL=false","root","K6beer@333");
			        Statement stmt2=con.createStatement();
					ResultSet rs=stmt2.executeQuery("select pid from product where Name="+ "\"" + Name + "\"");
					if(rs.next())
					{
						Long productid=rs.getLong(1);
						order.setPid(productid);
						
					ResultSet rs1=stmt2.executeQuery("select id from user where username="+  "\"" + username + "\"");
					if(rs1.next())
					{
						Long id=rs1.getLong(1);
						order.setId(id);
					
			
					ResultSet rs3=stmt2.executeQuery("select cid from cart where id="+ id +" AND "+"pid="+productid);
					if(rs3.next())
					{	
						Long cartid1=rs3.getLong(1);
						order.setCid(cartid1);
					}
					}
					}
					
					
				    LocalDateTime now = LocalDateTime.now();  
					order.setDate(now);
					order.setStatus("Order Placed");
					return ResponseEntity.ok(orderService.save(order));
				}
				catch(Exception e)
			{
					CRUDControllerException ce = new CRUDControllerException("602", "Something went wrong!! Please check put mapping in cart controller");
					return new ResponseEntity<CRUDControllerException> (ce, HttpStatus.BAD_REQUEST);
				}
				//return null;
	}
	
	// Updating status by Admin
	@PostMapping("/admin/update/{Oid}")
	public void update(@PathVariable Long Oid) {
		try
		{
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/olx?autoReconnect=true&useSSL=false","root","K6beer@333");
	    Statement stmt2=con.createStatement();
	    String status="Order Delivered";
	    stmt2.executeUpdate("update order_tbl set status= "+ "\"" + status + "\"" +"where oid="+Oid );
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
			
	}
	
	@DeleteMapping("/{username}/CancelOrder/{Name}")
	public void delete(@PathVariable String Name,@PathVariable String username) {
		try
		{
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/olx?autoReconnect=true&useSSL=false","root","K6beer@333");
	    Statement stmt2=con.createStatement();
		ResultSet rs=stmt2.executeQuery("select pid from product where name="+ "\"" + Name + "\"");
		if(rs.next())
		{
			Long productid=rs.getLong(1);
			ResultSet rs1=stmt2.executeQuery("select id from user where username="+  "\"" + username + "\"");
			if(rs1.next())
			{
			Long id=rs1.getLong(1);
			stmt2.executeUpdate("delete from order_tbl where pid="+ productid +" AND "+"id="+id );
//			if(rs2.next())
//			{
//				Long orderid=rs2.getLong(1);
//				orderService.findById(orderid).ifPresent(orderService::delete);
//				return ResponseEntity.ok().build();
//			}
		}
		}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		//return null;  ResponseEntity<Order>
	}
	
}
