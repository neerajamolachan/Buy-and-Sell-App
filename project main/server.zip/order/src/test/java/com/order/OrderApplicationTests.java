package com.order;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDateTime;
import java.util.Optional;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.order.Entity.Order;
import com.order.server.OrderService;

@SpringBootTest
class OrderApplicationTests {

	@Test
	void contextLoads() {
	}
	@Autowired
    private OrderService orderService;
    private Order order;

    @BeforeEach
    public void setUp() {
    	 order = new Order();
    	 order.setOid(1L);
         //LocalDateTime date=LocalDateTime.now();
         order.setDate(null);
         order.setCid(1L);
        
         order.setPid(1L);
         
         order.setStatus("delivered");
         
         order.setId(1L);
         
       
       
    }
    @AfterEach
    public void tearDown() {
    	orderService.deleteAll();
        order = null;
    }

    

    @Test
    public void givenOrderIdThenShouldReturnRespectiveOrder() {
    	LocalDateTime date=LocalDateTime.now();
        Order order = new Order(1L,1L,1L,1L,date,"placed");
        Order order1 = orderService.save(order);
        Optional<Order> optional = orderService.findById(order1.getOid());
        assertEquals(order1.getOid(), optional.get().getOid());
       // assertEquals(Order1.getDate(), optional.get().getDate());
        assertEquals(order1.getPid(), optional.get().getPid());
        assertEquals(order1.getId(), optional.get().getId());
        assertEquals(order1.getCid(), optional.get().getCid());
        assertEquals(order1.getStatus(), optional.get().getStatus());
       
    }


}
