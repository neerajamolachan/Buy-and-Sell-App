package com.order.Entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Order_tbl")
public class Order {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long Oid;
	@Column
	private Long Pid;
	@Column
	private Long Cid;
	@Column
	private Long id;
	@Column
	private LocalDateTime date;
	@Column
	private String status;
	
	public Order() {
		//super();
		// TODO Auto-generated constructor stub
	}

	public Long getOid() {
		return Oid;
	}

	public void setOid(Long oid) {
		Oid = oid;
	}

	public Long getPid() {
		return Pid;
	}

	public void setPid(Long pid) {
		Pid = pid;
	}

	public Long getCid() {
		return Cid;
	}

	public void setCid(Long cid) {
		Cid = cid;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public LocalDateTime getDate() {
		return date;
	}

	public void setDate(LocalDateTime date) {
		this.date = date;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Order(Long oid, Long pid, Long cid, Long id, LocalDateTime date, String status) {
		super();
		Oid = oid;
		Pid = pid;
		Cid = cid;
		this.id = id;
		this.date = date;
		this.status = status;
	}
	
}
