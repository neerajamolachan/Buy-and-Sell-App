package com.product;


import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;

//import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.boot.test.context.SpringBootTest;

//import org.springframework.boot.test.mock.mockito.MockBean;
//import org.springframework.test.web.servlet.MockMvc;
//
//import com.fasterxml.jackson.core.JsonProcessingException;
//import com.fasterxml.jackson.databind.ObjectMapper;
//import com.product.Controller.ProductController;
//import com.product.Service.ProductService;



import java.util.List;
import java.util.Optional;
import com.product.Entity.Product;
import com.product.Service.ProductService;
//@AutoConfigureTestDatabase(replace = Replace.NONE)

@SpringBootTest
class ProductApplicationTests {
	
	@Test
	void contextLoads() {
	}
//
////	@Autowired
////	private MockMvc mockMvc;
////	
////	@Autowired
////	private ObjectMapper objectMapper;
////	
////	@MockBean
////	private ProductController productController;
////	
////	@Test
////	public void testGetAll()throws JsonProcessingException,Exception{
////		when(ProductController.save(Mockito.any(ProductService.class))).thenReturn(dummyList().get(0));
////		mockMvc.perform(post("/employee/").content("{\"id\":1,\"name\":\"Helo\"}")
////				.contentType(MediaType.APPLICATION_JSON_VALUE))
////				.andDo(print())
////				.andExpect(status().isOk())
////				.andExpect(content().json("{\"id\":1,\"name\":\"John\"}"));
////	}
//	@Test
//	@Rollback(false)
//	public void testCreateProduct() {
//	    ResponseEntity<?> savedProduct = repo.createNew(new Product(1L,"Anju",56265,"good","User"));
//	     
//	    assertThat(savedProduct.equals(savedProduct));   //isGreaterThan(0);
//	}
//	
//	
////	@Test
////    public void testSaveNewProduct() {
////       repo.persist(new Product(4L, "lilly",8989, "best","admin"));
////                 
////        Product product = repository.findById("iPhone 10");
////         
////        assertThat(product.getName()).isEqualTo("iPhone 10");
////    }
//	@Autowired
//	private ProductController productController;
//	
//
//	@MockBean
//	private ProductService repository;
//
//	@Test
//	public void getAllTest() {
//		when(repository.findAll()).thenReturn(Stream
//				.of(new Product(33L, "denis",66366,"good","User"), new Product(98L, "harry", 66566,"great","User")).collect(Collectors.toList()));
//		assertEquals(2,productController.getAll());
//	}
//
//	@Test
//	public void updateTest() {
//		Product product= new Product(4L, "lilly",8989, "best","admin");
//		when(repository.save(product)).thenReturn(product);
//	
//	}
//	
//	@Test
//	public void deleteTest() {
//		Product product = new Product(4L, "lilly",8989, "best","admin");
//		repository.deleteById(4L);
//		verify(repository, times(1)).deleteById(4L);
//		
//		
//		
//		
//	}

	@Autowired
    private ProductService productService;
    private Product product;

    @BeforeEach
    public void setUp() {
    	 product = new Product();
         product.setPid(1L);
         product.setDescription("good product");       
         product.setPrice(20000);
         product.setName("samsungM42");
         product.setPostedBy("User");
       
       
    }
    @AfterEach
    public void tearDown() {
    	productService.deleteAll();
        product = null;
    }

    @Test
    public void givenGetAllProductThenShouldReturnListOfAllProduct() {
        Product product = new Product(2L,"Lenovo",11000,"good","User");
       Product product1 = new Product(3L,"Dell",60000,"great", "Admin");
       productService.save(product);
       productService.save(product1);

        List<Product> productList = (List<Product>) productService.findAll();
        assertEquals("Dell", productList.get(1).getName());
    }

    @Test
    public void givenProductIdThenShouldReturnRespectiveProduct() {
        Product product = new Product(3L,"LenovoK6",11000,"best","User");
        Product product1 = productService.save(product);
        Optional<Product> optional = productService.findById(product1.getPid());
        assertEquals(product1.getPid(), optional.get().getPid());
        assertEquals(product1.getDescription(), optional.get().getDescription());        
        assertEquals(product1.getPrice(), optional.get().getPrice());
        assertEquals(product1.getName(), optional.get().getName());
        assertEquals(product1.getPostedBy(), optional.get().getPostedBy());
    }
	
	
	
	
}
