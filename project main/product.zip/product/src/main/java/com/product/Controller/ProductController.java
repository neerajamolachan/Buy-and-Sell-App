package com.product.Controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.product.Entity.Product;
import com.product.Service.ProductService;
import com.product.exception.CRUDControllerException;


@RequestMapping("product")
@RestController
public class ProductController {
	private ProductService productService;
	@Autowired
	public void setProductService(ProductService productService) {
		this.productService = productService;
	}
	
	@GetMapping("{username}/all")
	public ResponseEntity<List<Product>> getAll() {
		return ResponseEntity.ok(productService.findAll());
		
	}
	
	@GetMapping("/{Pid}")
	public ResponseEntity<Product> findById(@PathVariable Long Pid) {
		return ResponseEntity.ok(productService.findById(Pid).orElse(null));
	}
	
	@PutMapping("/add")
	public ResponseEntity<?> createNew(@RequestBody Product p) {
		try{
			return ResponseEntity.ok(productService.save(p));
		}catch(Exception e)
		{
			CRUDControllerException ce = new CRUDControllerException("601", "Something went wrong!! Please check controller postmapping");
			return new ResponseEntity<CRUDControllerException>(ce, HttpStatus.BAD_REQUEST);
		}
		//	
	}
	
	@PostMapping("/update")
	public ResponseEntity<?> update(@RequestBody Product p) {
		try{
			return ResponseEntity.ok(productService.save(p));
		}catch(Exception e)
		{
			CRUDControllerException ce = new CRUDControllerException("600", "Something went wrong!! Please check controller postmapping");
			return new ResponseEntity<CRUDControllerException>(ce, HttpStatus.BAD_REQUEST);
		}
		//
	}
	

	@DeleteMapping("{username}/{Pid}")
	public ResponseEntity<Product> delete(@PathVariable Long Pid) {
		productService.findById(Pid).ifPresent(productService::delete);
		return ResponseEntity.ok().build();
	}

	
}
