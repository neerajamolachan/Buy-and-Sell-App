package com.product.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Product {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long Pid;
	@Column
	private String Name;
	@Column
	private double Price;
	@Column
	private String Description;
	@Column
	private String PostedBy;
	
	public String getPostedBy() {
		return PostedBy;
	}
	public void setPostedBy(String postedBy) {
		PostedBy = postedBy;
	}
	public Long getPid() {
		return Pid;
	}
	public void setPid(Long pid) {
		Pid = pid;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public double getPrice() {
		return Price;
	}
	public void setPrice(double price) {
		Price = price;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}
	public Product() {
		//super();
		// TODO Auto-generated constructor stub
	}
	public Product(Long pid, String name, double price, String description, String postedBy) {
		super();
		Pid = pid;
		Name = name;
		Price = price;
		Description = description;
		PostedBy = postedBy;
	}
	
	
	
	
	
}
