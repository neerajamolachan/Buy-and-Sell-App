package com.cart;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.cart.Entity.Cart;
import com.cart.Service.CartService;

@SpringBootTest
class CartApplicationTests {

	@Test
	void contextLoads() {
	}
	@Autowired
    private CartService cartService;
    private Cart cart;

    @BeforeEach
    public void setUp() {
    	 cart = new Cart();
    	 cart.setCid(1L);
         LocalDateTime date=LocalDateTime.now();
         cart.setDate(date);
         cart.setPid(1L);
         cart.setId(1L);
       
       
    }
    @AfterEach
    public void tearDown() {
        cartService.deleteAll();
        cart = null;
    }

    @Test
    public void givenGetAllcartThenShouldReturnListOfAllcart() {
    	LocalDateTime date=LocalDateTime.now();
        Cart cart = new Cart(1L,1L,2L,date);
       Cart cart1 = new Cart(1L,1L,1L,date);
        cartService.save(cart);
        cartService.save(cart1);
        List<Cart> cartList = (List<Cart>) cartService.findAll();
        assertEquals(1L, cartList.get(1).getPid());
    }

    @Test
    public void givencartIdThenShouldReturnRespectivecart() {
    	LocalDateTime date=LocalDateTime.now();
        Cart cart = new Cart(1L,1L,1L,date);
        Cart cart1 = cartService.save(cart);
        Optional<Cart> optional = cartService.findById(cart1.getCid());
        assertEquals(cart1.getCid(), optional.get().getCid());
        assertEquals(cart1.getPid(), optional.get().getPid());
        assertEquals(cart1.getId(), optional.get().getId());
    }



}
