package com.cart.Entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Cart {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long Cid;
	@Column
	private Long Pid;
	@Column
	private Long id;
	@Column
	private LocalDateTime date;


	public Cart(Long cid, Long pid, Long id, LocalDateTime date) {
		super();
		Cid = cid;
		Pid = pid;
		this.id = id;
		this.date = date;
	}


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public Long getCid() {
		return Cid;
	}


	public void setCid(Long cid) {
		Cid = cid;
	}


	public Long getPid() {
		return Pid;
	}


	public void setPid(Long pid) {
		Pid = pid;
	}



	public LocalDateTime getDate() {
		return date;
	}


	public void setDate(LocalDateTime date) {
		this.date = date;
	}


	public Cart() {
		//super();
		// TODO Auto-generated constructor stub
	}
	
}
