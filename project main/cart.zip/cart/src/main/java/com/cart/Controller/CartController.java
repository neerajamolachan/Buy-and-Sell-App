package com.cart.Controller;

import java.sql.Connection;


import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.util.List;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import org.springframework.web.bind.annotation.PutMapping;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.cart.Entity.Cart;
import com.cart.Service.CartService;
import com.cart.exeception.CRUDControllerException;

@RequestMapping("cart")
@RestController
public class CartController {
private CartService cartService;
@Autowired
public void setCartService(CartService cartService) {
	this.cartService = cartService;
}
//user name
@GetMapping("/{username}")
public List Display(@PathVariable String username) {
	try {	
			ArrayList al = new ArrayList();
			Class.forName("com.mysql.jdbc.Driver");
			
			Connection con1=DriverManager.getConnection("jdbc:mysql://localhost:3306/olx?autoReconnect=true&useSSL=false","root","K6beer@333");
	        Statement stmt3=con1.createStatement();
			ResultSet rs1=stmt3.executeQuery("select id from user where username="+  "\"" + username + "\"");
			
			if(rs1.next())
			{
				Long id=rs1.getLong(1);
				ResultSet rs2=stmt3.executeQuery("select pid from cart where id="+ id);
				if(rs2.next())
				{
					Long pid=rs2.getLong(1);
					ResultSet rs3=stmt3.executeQuery("select * from product where pid="+ pid);
					while(rs3.next())
						{
						
//						System.out.println(" ID : " +rs3.getLong(1)+"  ||  Descryption : "+rs3.getString(2)+
//				"  || Feedback :  "+rs3.getString(3)+"  ||  Price :  "+rs3.getDouble(4)+"  || Name : "+rs3.getString(5)+"  "
//						+ "||  Rating : "+rs3.getInt(6)+"  ||  Quantity : "+qty );
						
								al.add(" ID : " +rs3.getLong(1)+"  ||  Descryption : "+rs3.getString(2)+
						"  ||  Name :  "+rs3.getString(3)+"  || PostedBy: "+rs3.getString(4)+"  "
								+ "||  Price : "+rs3.getDouble(5));
		
						}
				return al;
				}
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	return null;	
}

@PutMapping("/{username}/{Name}")
public ResponseEntity<?> CreateNew(@PathVariable String username,@PathVariable String Name) {
	
		try {	
				Cart cart=new Cart();
				Class.forName("com.mysql.jdbc.Driver");
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/olx?autoReconnect=true&useSSL=false","root","K6beer@333");
		        Statement stmt2=con.createStatement();
				ResultSet rs=stmt2.executeQuery("select pid from product where name="+ "\"" + Name + "\"");
				if(rs.next())
				{
					Long productid=rs.getLong(1);
					cart.setPid(productid);
				}
				Class.forName("com.mysql.jdbc.Driver");
				Connection con1=DriverManager.getConnection("jdbc:mysql://localhost:3306/olx?autoReconnect=true&useSSL=false","root","K6beer@333");
		        Statement stmt3=con1.createStatement();
				ResultSet rs1=stmt3.executeQuery("select id from user where username="+  "\"" + username + "\"");
				if(rs1.next())
				{
					Long uid=rs1.getLong(1);
					cart.setId(uid);
				}
			    LocalDateTime now = LocalDateTime.now();  
				cart.setDate(now);
				return ResponseEntity.ok(cartService.save(cart));
			}
		catch(Exception e)
		{
			CRUDControllerException ce = new CRUDControllerException("602", "Something went wrong!! Please check put mapping in cart controller");
			return new ResponseEntity<CRUDControllerException> (ce, HttpStatus.BAD_REQUEST);
		}
		//	return null;
}

@DeleteMapping("/{Name}")
public ResponseEntity<Cart> delete(@PathVariable String Name) {
	try
	{
	Class.forName("com.mysql.jdbc.Driver");
	Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/olx?autoReconnect=true&useSSL=false","root","K6beer@333");
    Statement stmt2=con.createStatement();
	ResultSet rs=stmt2.executeQuery("select pid from product where name="+ "\"" + Name + "\"");
	if(rs.next())
	{
		Long productid=rs.getLong(1);
		ResultSet rs1=stmt2.executeQuery("select cid from cart where pid="+ productid );
		if(rs1.next())
		{
			Long cartid=rs1.getLong(1);
			cartService.findById(cartid).ifPresent(cartService::delete);
			return ResponseEntity.ok().build();
		}
	}
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
	return null;
}
}
